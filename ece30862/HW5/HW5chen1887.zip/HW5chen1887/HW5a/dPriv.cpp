#include "dPriv.h"

dPriv::dPriv( ) { }
dPriv::~dPriv( ){ }
void dPriv::print( ) { 
   cout << "dPriv" << endl;
   //cout << "privB: " << privB;
   //cout << ", protB: " << protB;
   //cout << ", publicB: " << publicB;
   cout << endl << endl;
}

