#ifndef __PACKING_H__
#define __PACKING_H__
#define STACK_SIZE 10
typedef struct _Item{
	int idx;
	char divid;
	double w;
	double h;
}Item;

typedef struct _Tnode {
	struct _Item item;
	double x;
	double y;
	struct _Tnode * left;
	struct _Tnode * right;
}Tnode;

typedef struct _Stack{
	int top;
	int size;
	struct _Tnode ** tnodes;
}Stack;

Tnode * load_tree(char * filename);
Tnode * calc_y(Tnode * tn, double * total_h);
Tnode * save_tree_and_calc_x(char * filename, Tnode * tn, double * total_w);
Tnode * tree_insert(Tnode * tn, Tnode * left, Tnode * right);
void tree_destroy(Tnode * root);
#endif

