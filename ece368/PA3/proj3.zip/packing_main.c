#include "packing.h"
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char ** argv) {
	if(argc < 3) {
		fprintf(stderr, "main exited because of invalid arguments");
		return EXIT_FAILURE;
	}
	double total_w = 0;
	double total_h = 0;
	
	Tnode * tn = load_tree(argv[1]);
	tn = calc_y(tn, &total_h);
	Tnode * result = save_tree_and_calc_x(argv[2], tn, &total_w);
	
	fprintf(stdout, "Width: %le\n", total_w);
	fprintf(stdout, "Height: %le\n", total_h);
	fprintf(stdout, "X-coordinate: %le\n", result -> x);
	fprintf(stdout, "Y-coordinate: %le\n", result -> y);
	
	tree_destroy(tn);
	return EXIT_SUCCESS;
}
