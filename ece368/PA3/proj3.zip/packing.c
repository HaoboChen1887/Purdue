#include "packing.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

static Tnode * Tnode_construct(Item item);
static void stack_init(Stack * sptr);
static Tnode * stack_top(Stack * sptr);
static int empty(Stack * sptr);
static Tnode * pop(Stack * sptr);
static int push(Stack * sptr, Tnode * tn);
static Item item_construct(Item item, int idx, char divid, double w, double h);
static bool is_label(Tnode * curr);
static bool diff_label(Tnode * prev, Tnode * curr);
static bool V_to_H(Tnode * prev, Tnode * curr);
static bool H_to_V(Tnode * prev, Tnode * curr);
static int large(int a, int b);

// load the tree information from given files
Tnode * load_tree(char * filename) {
	FILE * fp = fopen(filename, "r");
	if(fp == NULL) {
		fprintf(stderr, "load_tree exited because fopen failed");
		return NULL;
	}

	Tnode * tn = NULL;
	Tnode * left = NULL;
	Tnode * right = NULL;
	int idx = 0;
	char divid = '\0';
	double w = 0;
	double h = 0;
	Stack * sptr = malloc(sizeof(*sptr));
	stack_init(sptr);
	Item item = item_construct(item, 0, '\0', 0, 0);
	
	// Push the information into the stack
	// Use stack to build the tree directly
	while(fgetc(fp) != EOF) {
		fseek(fp, -1, SEEK_CUR);
		divid = fgetc(fp);
		if(divid == 'V' || divid == 'H') {
			item = item_construct(item, 0, divid, 0, 0);
			push(sptr, Tnode_construct(item));
			tn = pop(sptr);
			right = pop(sptr);
			left = pop(sptr);
			tn = tree_insert(tn, left, right);
			fgetc(fp);
		}
		else {
			fseek(fp, -1, SEEK_CUR);
			if(fscanf(fp, "%d(%le,%le)\n", &idx, &w, &h) == EOF) {
				fprintf(stderr, "load_tree exited because fscanf failed");
				fclose(fp);
				return NULL;
			}
			item = item_construct(item, idx, divid, w, h);
			push(sptr, Tnode_construct(item));
		}
		if(tn != NULL) {
			push(sptr, tn);
			tn = NULL;
		}
		item = item_construct(item, 0, '\0', 0, 0);
	}

	// Root is always the third item left over on the stack
	tn = sptr -> tnodes[2];
	free(sptr -> tnodes);
	free(sptr); 
	fclose(fp);
	return tn;
}

// pack the items in the tree on the y axis
// from bottom right to top left
Tnode * calc_y(Tnode * tn, double * total_h) {
	double curr_y = 0;
	double max_y = 0;
	Tnode * prev_label = NULL;
	Tnode * curr = tn;

	Stack * sptr = malloc(sizeof(*sptr));
	Stack * sptr_div = malloc(sizeof(*sptr));
	stack_init(sptr);
	stack_init(sptr_div);

	// inorder traversal with stack starting from the right branch
	do {
		while(curr != NULL) {
			if(curr != stack_top(sptr)) {
				push(sptr, curr);
			}
			curr = curr -> right;
		}
		curr = pop(sptr);
		if(curr != NULL) {
			// When it is a dividing label
			// calculate y coordinate from bottom right
			if(is_label(curr)) {
				if(!empty(sptr_div)) {
					prev_label = pop(sptr_div);
				}
				push(sptr_div, curr);
				if(prev_label != NULL) {
					if(diff_label(prev_label, curr)) {
						if(V_to_H(prev_label, curr)) {
							max_y += curr_y;
						}
						else if(H_to_V(prev_label, curr)) {
							max_y -= curr_y;
						}
					}
				}
			}
			// When it's not a dividing label
			else {
				Tnode * curr_label = stack_top(sptr_div);
				// Assign coordinates according to the current label
				if(curr_label != NULL) {
					if(curr_label -> item.divid == 'V') {
						curr -> y += max_y;
						curr_y = large(curr -> item.h, curr_y);
					}
					else if(curr_label -> item.divid == 'H') {
						curr -> y += max_y;
						curr_y = curr -> item.h;
						max_y += curr_y;
					}
				}
				else {
					curr -> y += max_y;
					curr_y += curr -> item.h;
				}
			}
		}
		Tnode * curr_label = stack_top(sptr_div);
		// Calculate total height
		if(curr_label != NULL) {
			if(curr_label -> item.divid == 'V') {
				*total_h = max_y + large(curr_y, curr -> item.h);
			}
			else if(curr_label -> item.divid == 'H') {
				*total_h = max_y;
			}
		}
		if(curr -> left != NULL) {
			push(sptr, curr -> left);
		}
		curr = curr -> left;
	}while(!empty(sptr));
	
	free(sptr_div -> tnodes);
	free(sptr_div);
	free(sptr -> tnodes);
	free(sptr);
	return tn;
}

// Save the tree structure to the file specified
Tnode * save_tree_and_calc_x(char * filename, Tnode * tn, double * total_w) {
	FILE * fp = fopen(filename, "w");
	double curr_x = 0;
	double max_x = 0;

	Tnode * curr = tn;
	Tnode * result = NULL; // get the node with largest index

	Stack * sptr = malloc(sizeof(*sptr));
	Stack * sptr_div = malloc(sizeof(*sptr));
	stack_init(sptr);
	stack_init(sptr_div);

	// inorder traversal with stack from the left branch
	do {
		while(curr != NULL) {
			if(curr != stack_top(sptr)) {
				push(sptr, curr);
			}
			curr = curr -> left;
		}
		curr = pop(sptr);
		result = curr; // get the node with largest index
		if(curr != NULL) {
			// When it is a dividing label
			// calculate x coordinate from top left
			if(is_label(curr)) {
				if(!empty(sptr_div)) {
					pop(sptr_div);
				}
				push(sptr_div, curr);
			}
			// When it's not a dividing label
			else {
				Tnode * curr_label = stack_top(sptr_div);
				// Assign coordinates according to the current label
				if(curr_label != NULL) {
					if(curr_label -> item.divid == 'V') {
						curr -> x += curr_x;
						curr_x += curr -> item.w;
					}
					else if(curr_label -> item.divid == 'H') {
						curr_x = 0;
						curr -> x = curr_x;
						curr_x += curr -> item.w;
					}
				}
				else {
					curr -> x += max_x;
					curr_x += curr -> item.w;
				}
				max_x = large(curr_x, max_x);
			}
			// write the calculate tree into the file specified 
			if(!is_label(curr)) {
				fprintf(fp, "%d %le %le %le %le\n", curr -> item.idx, curr -> item.w, curr -> item.h, curr -> x, curr -> y);
			}
			
		}
		if(curr -> right != NULL) {
			push(sptr, curr -> right);
		}
		curr = curr -> right;
	}while(!empty(sptr));
	*total_w = max_x;
	
	free(sptr_div -> tnodes);
	free(sptr_div);
	free(sptr -> tnodes);
	free(sptr);
	fclose(fp);
	return result;
}

// insert a new node with the input values;
Tnode * tree_insert(Tnode * tn, Tnode * left, Tnode * right) {
	tn -> right = right;
	tn -> left = left;
	return tn;
}

// destroy the entire tree and free allocated memory
void tree_destroy(Tnode * tn) {
	if(tn == NULL) {
		return;
	}
	tree_destroy(tn -> left);
	tree_destroy(tn -> right);
	free(tn);
}

// initialize or construct a tree node
static Tnode * Tnode_construct(Item item) {
	Tnode * tn;
	tn = malloc(sizeof(Tnode));
	if(tn == NULL) {
		fprintf(stderr, "TNode_construct exited because malloc failed");
		return NULL;
	}
	tn -> left = NULL;
	tn -> right = NULL;
	tn -> item.divid = item.divid;
	tn -> item.idx = item.idx;
	tn -> item.w = item.w;
	tn -> item.h = item.h;
	tn -> x = 0;
	tn -> y = 0;
	return tn;
}

// Initialize a stack structure
static void stack_init(Stack * sptr) {
	sptr -> top = -1;
	sptr -> size = STACK_SIZE;
	sptr -> tnodes  = malloc(sizeof(Tnode*) * sptr -> size);
	if(sptr -> tnodes == NULL) {
		fprintf(stderr, "stack_init exited because malloc failed");
		return;
	}
}

// return the top element on the stack
static Tnode * stack_top(Stack * sptr) {
	return (empty(sptr) ? NULL : sptr -> tnodes[sptr -> top]);
}

// check if the stack is empty
static int empty(Stack * sptr) {
	return (sptr -> top < 0);
}

// pop the top item on the stack, return a Tnode *
static Tnode * pop(Stack * sptr) {
	Tnode * results = sptr -> tnodes[sptr -> top];
	sptr -> top --;
	return results;
}

// Push a Tnode onto the stack
static int push(Stack * sptr, Tnode * tn) {
	if(sptr -> top >= sptr -> size - 1) {
		sptr -> tnodes = realloc(sptr -> tnodes, sizeof(Tnode *) * sptr -> size * 2);
		if(sptr -> tnodes == NULL) {
			fprintf(stderr, "push exited because malloc failed");
			return 0;
		}
	}
	sptr -> tnodes[++(sptr -> top)] = tn;
	return 1;
}

// Initialize an item struct 
static Item item_construct(Item item, int idx, char divid, double w, double h) {
	item.idx = idx;
	item.divid = divid;
	item.w = w;
	item.h = h;
	return item;
}

// Return the larger number of the two
static int large(int a, int b) {
	return ((a > b) ? a : b);
}

// return true if the tnode is a label
static bool is_label(Tnode * curr) {
	return (curr != NULL && (curr -> item.divid == 'V' || curr -> item.divid == 'H'));
}

// return true if to continuous labels are different
static bool diff_label(Tnode * prev, Tnode * curr) {
	return (prev -> item.divid != curr -> item.divid);
}

// return true if label change from V to H
static bool V_to_H(Tnode * prev, Tnode * curr) {
	return (prev -> item.divid == 'V' && curr -> item.divid == 'H');
}

// return true if label change from H to V
static bool H_to_V(Tnode * prev, Tnode * curr) {
	return (prev -> item.divid == 'H' && curr -> item.divid == 'V');
}

